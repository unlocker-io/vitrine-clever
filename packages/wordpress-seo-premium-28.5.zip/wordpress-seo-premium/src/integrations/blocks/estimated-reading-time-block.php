<?php

namespace Yoast\WP\SEO\Premium\Integrations\Blocks;

use Yoast\WP\SEO\Integrations\Blocks\Dynamic_Block_V3;

/**
 * Estimated_Reading_Time_Block class.
 *
 * @phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded
 */
class Estimated_Reading_Time_Block extends Dynamic_Block_V3 {

	/**
	 * The name of the block.
	 *
	 * @var string
	 */
	protected $block_name = 'estimated-reading-time';

	/**
	 * Holds the clock icon HTML.
	 *
	 * @var string
	 */
	protected $clock_icon = '<span class="yoast-reading-time__icon"><svg aria-hidden="true" focusable="false" data-icon="clock" width="20" height="20" fill="none" stroke="currentColor" style="display:inline-block;vertical-align:-0.1em" role="img" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg></span><span class="yoast-reading-time__spacer" style="display:inline-block;width:1em"></span>';

	/**
	 * The editor script for the block.
	 *
	 * @var string
	 */
	protected $script = 'wp-seo-premium-dynamic-blocks';

	/**
	 * The constructor.
	 */
	public function __construct() {
		$this->base_path = \WPSEO_PREMIUM_PATH . 'assets/blocks/dynamic-blocks/';
	}

	/**
	 * Presents the block output.
	 *
	 * @param array<string, bool|string|int|array> $attributes The block attributes.
	 * @param string                               $content    The content.
	 *
	 * @return string The block output.
	 */
	public function present( $attributes, $content = '' ) {

		$content = \preg_replace(
			'/<span class="yoast-reading-time__time-unit">.*<\/span>/',
			'<span class="yoast-reading-time__time-unit"> ' . \sprintf( \_n( 'minute', 'minutes', $attributes['estimatedReadingTime'], 'wordpress-seo-premium' ), $attributes['estimatedReadingTime'] ) . '</span>',
			$content,
			1,
		);
		if ( $attributes['showIcon'] ) {
			// Replace 15.7 icon placeholder.
			$content = \preg_replace(
				'/ICON_PLACEHOLDER/',
				$this->clock_icon,
				$content,
				1,
			);

			// Replace the 15.8+ icon placeholder.
			return \preg_replace(
				'/<span class="yoast-reading-time__icon"><\/span>/',
				$this->clock_icon,
				$content,
				1,
			);
		}

		return $content;
	}
}
